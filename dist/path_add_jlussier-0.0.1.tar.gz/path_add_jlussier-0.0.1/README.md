# Example Package

This is a small python package to simplify adding working directories to path, from a sub directory.  it may be expanded in the future.